from morse.morse import morse_encrypt, morse_decrypt

__all__ = ['morse_encrypt', 'morse_decrypt']