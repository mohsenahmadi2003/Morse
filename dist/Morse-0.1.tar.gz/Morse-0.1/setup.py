from setuptools import *

setup(
    name="Morse",
    version="0.1",
    description="For Morse encryption and decryption",
    url="",
    author="Mohsen Ahmadi",
    author_email="MohsenAhmadi2003@yahoo.com",
    license="MIT",
    packages=["morse"],
    zip_safe=False
)